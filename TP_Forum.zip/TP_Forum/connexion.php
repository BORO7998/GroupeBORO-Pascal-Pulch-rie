<?php

$cn=mysqli_connect('localhost','forum2020','123456','forum2020') ;


?>